<?php

use yii\helpers\Html;

?>
<div class="site-error">

    <p>
        The above error occurred while the Web server was processing your request.
    </p>
    <p>
        Please contact us if you think this is a server error. Thank you.
    </p>
</div>
